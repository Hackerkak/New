﻿
namespace GitTfs.Core
{
    public class TfsCheckinNote : ITfsCheckinNote
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}