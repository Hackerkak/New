﻿using System;

namespace GitTfs.Core
{
    [AttributeUsage(AttributeTargets.Class)]
    public class RequiresValidGitRepositoryAttribute : Attribute
    {
    }
}
