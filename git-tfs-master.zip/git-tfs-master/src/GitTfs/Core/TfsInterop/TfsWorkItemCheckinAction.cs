﻿
namespace GitTfs.Core.TfsInterop
{
    public enum TfsWorkItemCheckinAction
    {
        Associate = 0x402,
        None = 0,
        Resolve = 0x401
    }
}
