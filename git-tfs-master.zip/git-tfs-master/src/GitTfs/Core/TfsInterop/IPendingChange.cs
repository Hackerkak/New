
namespace GitTfs.Core.TfsInterop
{
    public interface IPendingChange
    {
    }
}