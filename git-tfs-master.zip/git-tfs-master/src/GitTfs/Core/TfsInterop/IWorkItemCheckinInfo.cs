
namespace GitTfs.Core.TfsInterop
{
    public interface IWorkItemCheckinInfo
    {
    }
}