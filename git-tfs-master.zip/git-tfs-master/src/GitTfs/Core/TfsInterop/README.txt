﻿My plan:

all the TFS classes should be duck-typed and/or only used by reflection.

2005/2008 should be able to use the same driver at this point, and 2010 will need a slightly different driver.