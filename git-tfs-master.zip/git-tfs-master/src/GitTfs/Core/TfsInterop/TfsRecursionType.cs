﻿
namespace GitTfs.Core.TfsInterop
{
    public enum TfsRecursionType
    {
        None,
        OneLevel,
        Full
    }
}
