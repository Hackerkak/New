﻿
namespace GitTfs.Core.TfsInterop
{
    public interface IWorkItemCheckedInfo
    {
    }
}
