﻿
namespace GitTfs.Core.TfsInterop
{
    public enum TfsItemType
    {
        Any,
        Folder,
        File
    }
}
