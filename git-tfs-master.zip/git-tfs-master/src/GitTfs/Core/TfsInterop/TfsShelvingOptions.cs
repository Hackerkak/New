﻿
namespace GitTfs.Core.TfsInterop
{
    public enum TfsShelvingOptions
    {
        None,
        Move,
        Replace
    }
}
