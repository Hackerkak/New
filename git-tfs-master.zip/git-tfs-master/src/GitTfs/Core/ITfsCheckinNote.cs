﻿
namespace GitTfs.Core
{
    public interface ITfsCheckinNote
    {
        string Name { get; set; }
        string Value { get; set; }
    }
}