﻿using System.Reflection;

[assembly: AssemblyCompany("GitTfs")]
[assembly: AssemblyProduct("GitTfs")]
[assembly: AssemblyCopyright("Copyright © 2009-2019")]
[assembly: AssemblyVersion("0.0.1")]
[assembly: AssemblyFileVersion("0.0.1")]
[assembly: AssemblyInformationalVersion("0.0.1+f2db4336ba.shouldBeGeneratedByCakeDuringBuild")]

