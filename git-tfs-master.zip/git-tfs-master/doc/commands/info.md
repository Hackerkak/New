## Summary

The `info` command give you some information about your git-tfs repository.

It will display:

- the version of git used
- the version of git-tfs used
- information data about each Tfs remote initialized in your repository.