## Summary

The `help` command list all the git-tfs commands and give you a little help on how to use git-tfs command line.