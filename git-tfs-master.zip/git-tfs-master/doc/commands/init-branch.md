## Summary

The `init-branch` command creates a git branch for an existing TFS branch (or all) and fetch all the changeset of the TFS branch.

_This command has been removed. Use [branch --init](branch.md#init-an-existing-tfs-branches) instead (usage remains the same!)._

## See also

* [branch](branch.md)
